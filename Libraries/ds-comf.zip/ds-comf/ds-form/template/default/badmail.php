<div class="form-head">Ошибка!</div>
<div class="error-report">
	<div class="text-report">
		<p>Ваше сообщение не отправлено.</p>
		<p>Попробуйте отправить письмо позже.</p>
	</div>
</div>