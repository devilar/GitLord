<div class="form-head">Отправлено</div>
<div class="error-report">
	<div class="text-report">
		<p>Спасибо! Ваше сообщение отправлено.</p>
		<p>Отправить <a href="#" class="repeatform">новое</a> сообщение?<p>
	</div>
</div>