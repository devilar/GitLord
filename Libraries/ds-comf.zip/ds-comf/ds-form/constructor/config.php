<?php
return 'a:3:{s:5:"login";s:5:"admin";s:8:"password";s:32:"0192023a7bbd73250516f069df18b500";s:6:"change";b:0;}';