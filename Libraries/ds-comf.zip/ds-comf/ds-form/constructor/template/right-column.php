<div id="slide_css_wrap">
  <div class="slide_css">
    <h3>CSS стили формы</h3>
    <form id="css-form" class="col-sm-12" role="form">
      <textarea class="form-control" name="form-css" rows="15"><?php echo $stylesheet?></textarea>
      <div class="row">
        <div class="col-sm-12">
          <button class="savecss btn btn-success" type="button">
              <span class="glyphicon glyphicon-ok"></span> Применить CSS
          </button>
        </div>
      </div>
    </form>
  </div>
  <div class="slide_css_label">CSS</div>
</div>