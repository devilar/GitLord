<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Конструктор форм</title>
    <link type="image/x-icon" href="constructor/images/constructor.ico" rel="icon">
	<link type="image/x-icon" href="constructor/images/constructor.ico" rel="shortcut icon">
	<script src="//code.jquery.com/jquery-1.9.1.min.js"></script>
	<link href="constructor/css/bootstrap.css" rel="stylesheet">
	<link href="constructor/css/constructor.css" rel="stylesheet">
</head>
<body>